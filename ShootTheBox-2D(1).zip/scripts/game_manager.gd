extends Node
## Central game state: score, 60-second timer, waves and restart.

@export var box_scene: PackedScene = preload("res://scenes/Box.tscn")
@export var starting_boxes := 15
@export var round_time := 60.0

var score := 0
var time_left := round_time
var wave := 1
var game_over := false
var spawning := false

func _ready() -> void:
    randomize()
    var ui := get_tree().get_first_node_in_group("game_ui")
    if is_instance_valid(ui):
        ui.restart_pressed.connect(restart_game)
    spawn_wave()

func _process(delta: float) -> void:
    if game_over:
        return

    time_left = maxf(0.0, time_left - delta)
    _update_ui()

    if time_left <= 0.0:
        end_game()
        return

    if not spawning and get_tree().get_nodes_in_group("boxes").is_empty():
        wave += 1
        spawn_wave()

func spawn_wave() -> void:
    spawning = true
    var amount := starting_boxes + (wave - 1) * 5

    for i in amount:
        var box := box_scene.instantiate()
        box.global_position = _random_spawn_position()
        box.destroyed.connect(_on_box_destroyed)
        get_tree().current_scene.add_child.call_deferred(box)

    spawning = false

func _random_spawn_position() -> Vector2:
    return Vector2(randf_range(130.0, 1150.0), randf_range(130.0, 590.0))

func _on_box_destroyed(points: int) -> void:
    if not game_over:
        score += points
        _update_ui()

func _update_ui() -> void:
    var ui := get_tree().get_first_node_in_group("game_ui")
    if is_instance_valid(ui):
        ui.refresh_score(score)
        ui.refresh_timer(time_left)

func end_game() -> void:
    game_over = true
    var ui := get_tree().get_first_node_in_group("game_ui")
    if is_instance_valid(ui):
        ui.show_game_over(score)

func restart_game() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
