extends Control
## Mobile left-stick input. Returns normalized Vector2 movement.

@export var radius := 70.0
var value := Vector2.ZERO
var touch_id := -1

func _ready() -> void:
    add_to_group("virtual_joystick")
    queue_redraw()

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and touch_id == -1:
            touch_id = event.index
            _set_value(event.position)
        elif not event.pressed and event.index == touch_id:
            touch_id = -1
            value = Vector2.ZERO
            queue_redraw()

    elif event is InputEventScreenDrag and event.index == touch_id:
        _set_value(event.position)

func _set_value(local_position: Vector2) -> void:
    var center := size * 0.5
    value = (local_position - center).limit_length(radius) / radius
    queue_redraw()

func get_value() -> Vector2:
    return value

func _draw() -> void:
    draw_circle(size * 0.5, radius, Color(0.1, 0.1, 0.1, 0.35))
    draw_circle(size * 0.5 + value * radius, radius * 0.42, Color(1, 1, 1, 0.65))
