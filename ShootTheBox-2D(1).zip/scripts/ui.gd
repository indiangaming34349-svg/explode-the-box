extends CanvasLayer
## HUD and mobile controls.

signal restart_pressed

@onready var score_label: Label = $HUD/ScoreLabel
@onready var timer_label: Label = $HUD/TimerLabel
@onready var ammo_label: Label = $HUD/AmmoLabel
@onready var game_over_panel: Panel = $HUD/GameOverPanel
@onready var player: CharacterBody2D = get_tree().get_first_node_in_group("player")

func _ready() -> void:
    add_to_group("game_ui")

    $HUD/ShootButton.pressed.connect(_on_shoot_pressed)
    $HUD/ReloadButton.pressed.connect(_on_reload_pressed)
    $HUD/PauseButton.pressed.connect(_on_pause_pressed)
    $HUD/GameOverPanel/RestartButton.pressed.connect(func(): restart_pressed.emit())

    if is_instance_valid(player):
        refresh_ammo(player.ammo, player.max_ammo)

    game_over_panel.hide()

func refresh_score(value: int) -> void:
    score_label.text = "SCORE: %06d" % value

func refresh_timer(value: float) -> void:
    timer_label.text = "TIME: %02d" % ceili(value)

func refresh_ammo(value: int, maximum: int) -> void:
    ammo_label.text = "AMMO: %02d/%02d" % [value, maximum]

func _on_shoot_pressed() -> void:
    if is_instance_valid(player):
        player.request_shoot()

func _on_reload_pressed() -> void:
    if is_instance_valid(player):
        player.reload()

func _on_pause_pressed() -> void:
    get_tree().paused = not get_tree().paused
    $HUD/PauseButton.text = "RESUME" if get_tree().paused else "PAUSE"

func flash_hit() -> void:
    $HUD/HitFlash.modulate.a = 0.75
    var tween := create_tween()
    tween.tween_property($HUD/HitFlash, "modulate:a", 0.0, 0.12)

func show_game_over(final_score: int) -> void:
    $HUD/GameOverPanel/FinalScore.text = "FINAL SCORE: %06d" % final_score
    game_over_panel.show()
