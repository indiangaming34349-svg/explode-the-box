extends Area2D
## Fast projectile that disappears after hitting a box or wall.

@export var speed := 900.0
var direction := Vector2.RIGHT

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    area_entered.connect(_on_area_entered)

func _physics_process(delta: float) -> void:
    global_position += direction.normalized() * speed * delta

    if global_position.x < -50.0 or global_position.x > 1330.0 \
    or global_position.y < -50.0 or global_position.y > 770.0:
        queue_free()

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("boxes") and body.has_method("hit"):
        body.hit()
        queue_free()
    elif body.is_in_group("walls"):
        queue_free()

func _on_area_entered(area: Area2D) -> void:
    if area.is_in_group("boxes") and area.has_method("hit"):
        area.hit()
        queue_free()
