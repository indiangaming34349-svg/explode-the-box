extends RigidBody2D
## One-hit target with simple random/bouncing movement.

signal destroyed(points: int)

@export var speed := 120.0
var hp := 1
var alive := true

func _ready() -> void:
    add_to_group("boxes")
    speed *= randf_range(0.75, 1.35)
    linear_velocity = Vector2.RIGHT.rotated(randf_range(0.0, TAU)) * speed
    angular_velocity = randf_range(-2.0, 2.0)

func _physics_process(_delta: float) -> void:
    # Bounce inside the playable room.
    if global_position.x <= 90.0 or global_position.x >= 1190.0:
        linear_velocity.x *= -1.0
    if global_position.y <= 90.0 or global_position.y >= 630.0:
        linear_velocity.y *= -1.0

    if linear_velocity.length() > 0.01:
        linear_velocity = linear_velocity.normalized() * speed

func hit() -> void:
    if not alive:
        return

    hp -= 1
    if hp <= 0:
        alive = false
        destroyed.emit(10)
        _spawn_break_particles()
        queue_free()

func _spawn_break_particles() -> void:
    var particles := GPUParticles2D.new()
    particles.amount = 16
    particles.lifetime = 0.45
    particles.one_shot = true
    particles.explosiveness = 1.0
    particles.position = global_position

    var material := ParticleProcessMaterial.new()
    material.direction = Vector3(0, -1, 0)
    material.spread = 180.0
    material.initial_velocity_min = 80.0
    material.initial_velocity_max = 180.0
    material.gravity = Vector3(0, 220, 0)
    particles.process_material = material
    particles.texture = preload("res://assets/box.png")

    get_tree().current_scene.add_child(particles)
    particles.emitting = true
    get_tree().create_timer(0.7).timeout.connect(particles.queue_free)
