extends CharacterBody2D
## Player movement, aiming, shooting and ammo management.

@export var speed := 320.0
@export var max_ammo := 10
@export var bullet_scene: PackedScene = preload("res://scenes/Bullet.tscn")

var ammo := max_ammo
var shoot_requested := false
var joystick: Node

@onready var gun_tip: Marker2D = $GunTip

func _ready() -> void:
    add_to_group("player")
    joystick = get_tree().get_first_node_in_group("virtual_joystick")

func _physics_process(_delta: float) -> void:
    var keyboard_input := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    var stick_input := Vector2.ZERO

    if is_instance_valid(joystick):
        stick_input = joystick.get_value()

    var movement := stick_input if stick_input.length() > 0.05 else keyboard_input
    velocity = movement * speed
    move_and_slide()

    # Mouse position also works for desktop and browser touch emulation.
    look_at(get_global_mouse_position())

    if Input.is_action_just_pressed("shoot") or shoot_requested:
        shoot_requested = false
        shoot()

    if Input.is_action_just_pressed("reload"):
        reload()

    global_position.x = clamp(global_position.x, 80.0, 1200.0)
    global_position.y = clamp(global_position.y, 80.0, 640.0)

func request_shoot() -> void:
    shoot_requested = true

func shoot() -> void:
    if ammo <= 0:
        return

    ammo -= 1
    var bullet := bullet_scene.instantiate()
    bullet.global_position = gun_tip.global_position
    bullet.direction = Vector2.RIGHT.rotated(global_rotation)
    bullet.rotation = global_rotation
    get_tree().current_scene.add_child(bullet)

    _update_ammo_ui()

func reload() -> void:
    ammo = max_ammo
    _update_ammo_ui()

func _update_ammo_ui() -> void:
    var ui := get_tree().get_first_node_in_group("game_ui")
    if is_instance_valid(ui):
        ui.refresh_ammo(ammo, max_ammo)
